#!/bin/bash
ORACLE_HOME=/u01/app/oracle/product/19.3.0/dbhome_1
ORACLE_SID=FOGDB
PATH=${ORACLE_HOME}/bin:${PATH}
REPORT_DIR=/backup/awr
DATE=$(/bin/date +%Y%m%d_%H%M)
SQLPLUS=/u01/app/oracle/product/19.3.0/dbhome_1/bin/sqlplus

BID=$(${SQLPLUS} -s / as sysdba <<EOF
set heading off feedback off verify off echo off pagesize 0 linesize 200 trimspool on
select min(snap_id) from dba_hist_snapshot
where trunc(begin_interval_time) = trunc(sysdate);
exit;
EOF
)

#BID는 오늘 날짜 기준 snapshot에서 가장 낮은 ID를 가져오는 단계

BID=$(echo $BID | xargs)

EID=$(${SQLPLUS} -s / as sysdba <<EOF
set heading off feedback off verify off echo off pagesize 0 linesize 200 trimspool on
select max(snap_id) from dba_hist_snapshot;
exit;
EOF
)

#EID는 오늘 날짜 기준 snapshot에서 가장 높은 ID를 가져오는 단계

EID=$(echo $EID | xargs)

if [[ -z "$BID" || -z "$EID" ]]; then
  echo "Snapshot Id를 가져오지 못했습니다. AWR 생성 중단."
  exit 1
fi
#오류 메세지


echo "스냅샷 시작 Id: $BID, 스냅샷 끝 Id: $EID"

${SQLPLUS} -s / as sysdba <<EOF
set termout off feedback off echo off verify off
spool $REPORT_DIR/awr_${DATE}.html

define report_type='html'
define num_days=1
define begin_snap=$BID
define end_snap=$EID

@${ORACLE_HOME}/rdbms/admin/awrrpt.sql
spool off
exit
EOF

echo "AWR 생성 완료: $REPORT_DIR/awr_${DATE}.html"
