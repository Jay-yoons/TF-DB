#!/bin/bash
TO_EMAIL=$1
DATE=$(/usr/bin/date +%Y%m%d)
REPORT_DIR=/mnt/nfs/awr
FILE=$(ls $REPORT_DIR/awr_${DATE}*.html 2>/dev/null | head -n1)
FROM_EMAIL="unsang2007@gmail.com"#이메일
APP_PASSWORD=""#비밀번호
SUBJECT="AWR 리포트 발송" #mail 제목
BODY="첨부된 AWR 파일 확인 부탁드립니다." #메일 내용
MAILX=/usr/bin/mailx
RM=/usr/bin/rm


if [[ -z "${FILE}" ]]; then
    echo "첨부할 파일이 없습니다: ${FILE}"
    exit 1
fi

echo "${BODY}" | ${MAILX} -v \
  -s "${SUBJECT}" \
  -a "${FILE}" \
  -S smtp="smtp.gmail.com:587" \
  -S smtp-use-starttls \
  -S ssl-verify=ignore \
  -S smtp-auth=login \
  -S smtp-auth-user="${FROM_EMAIL}" \
  -S smtp-auth-password="${APP_PASSWORD}" \
  -S from="${FROM_EMAIL}" \
  "${TO_EMAIL}"

$RM -f "${FILE}"
echo "AWR 파일 발송 및 삭제 완료"

