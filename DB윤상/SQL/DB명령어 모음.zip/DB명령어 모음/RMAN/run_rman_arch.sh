export ORACLE_HOME=/u01/app/oracle/product/19.3.0/dbhome_1
export ORACLE_SID=FOGDB
export PATH=$ORACLE_HOME/bin:$PATH

LOGDIR=/backup/log
RMAN=/u01/app/oracle/product/19.3.0/dbhome_1/bin/rman
$RMAN target / <<EOF > $LOGDIR/rman_arch_$(/bin/date +%a).log 2>&1
RUN {
  BACKUP ARCHIVELOG ALL
    FORMAT '/backup/rman/arch/%d_ARCH_%T_%U.bkp'
    DELETE INPUT;
  DELETE NOPROMPT OBSOLETE;
}
EOF

