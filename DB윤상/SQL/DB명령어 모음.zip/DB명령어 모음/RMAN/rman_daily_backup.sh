#!/bin/bash
export ORACLE_HOME=/u01/app/oracle/product/19.3.0/dbhome_1
export ORACLE_SID=FOGDB
export PATH=$ORACLE_HOME/bin:$PATH

RMAN=/u01/app/oracle/product/19.3.0/dbhome_1/bin/rman
DAY=$(/bin/date +%a)

LOGDIR=/backup/log
mkdir -p $LOGDIR

case $DAY in
  Sun) SCRIPT=/backup/scripts/rman_backup_sun.rman ;;
  Mon) SCRIPT=/backup/scripts/rman_backup_mon.rman ;;
  Tue) SCRIPT=/backup/scripts/rman_backup_tue.rman ;;
  Wed) SCRIPT=/backup/scripts/rman_backup_wed.rman ;;
  Thu) SCRIPT=/backup/scripts/rman_backup_thu.rman ;;
  Fri) SCRIPT=/backup/scripts/rman_backup_fri.rman ;;
  Sat) SCRIPT=/backup/scripts/rman_backup_sat.rman ;;
  *) echo "Unknown day: $DAY"; exit 1 ;;
esac

$RMAN target / cmdfile=$SCRIPT log=$LOGDIR/rman_${DAY}.log
